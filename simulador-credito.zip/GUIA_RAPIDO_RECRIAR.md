# CREDMAIS — Guia Rápido para Recriar em 30 Minutos

## 1️⃣ Criar Projeto Manus (2 min)
- Plataforma Manus → New Project
- Nome: `simulador-credito`
- Template: **Web App (tRPC + Auth + Database)**
- Features: ✅ Database, ✅ Server, ✅ User Auth

## 2️⃣ Banco de Dados (5 min)
```bash
# Copiar arquivo: drizzle/schema.ts
# (4 tabelas: creditUsers, simulations, proposals, payments)

pnpm drizzle-kit generate
pnpm drizzle-kit migrate
```

## 3️⃣ Backend (10 min)
Copiar/criar arquivos:
- `server/db.ts` — 8 funções de query
- `server/routers.ts` — 5 procedures tRPC
  - `credit.lookup` (consulta CPF)
  - `credit.simulate` (gera propostas)
  - `credit.acceptProposal` (aceita + gera Pix)
  - `credit.getPayment` (retorna Pix)
  - `credit.confirmPayment` (confirma)

Instalar: `pnpm add axios qrcode`

## 4️⃣ Frontend (10 min)
Copiar/criar arquivos:
- `client/src/index.css` — Tema rosa/magenta
- `client/src/App.tsx` — 4 rotas
- `client/src/pages/Home.tsx` — Formulário
- `client/src/pages/Simulation.tsx` — Perfil + propostas
- `client/src/pages/Proposal.tsx` — Detalhes
- `client/src/pages/Payment.tsx` — QR Code Pix

## 5️⃣ Secrets (2 min)
Management UI → Settings → Secrets:
- `CPFCNPJ_API_TOKEN` = seu token de cpfcnpj.com.br

## 6️⃣ Testar (1 min)
```bash
pnpm test
pnpm dev
```

## 7️⃣ Deploy (2 min)
- Salvar checkpoint
- Clicar "Publish"
- Escolher domínio

---

## Arquivos Essenciais

| Arquivo | Linhas | Descrição |
|---------|--------|-----------|
| `drizzle/schema.ts` | 92 | 4 tabelas do banco |
| `server/db.ts` | 121 | Query helpers |
| `server/routers.ts` | 345 | Procedures tRPC |
| `client/src/index.css` | 150 | Estilos CREDMAIS |
| `client/src/App.tsx` | 39 | Rotas |
| `client/src/pages/Home.tsx` | 300+ | Página inicial |
| `client/src/pages/Simulation.tsx` | 350+ | Simulação |
| `client/src/pages/Proposal.tsx` | 200+ | Proposta |
| `client/src/pages/Payment.tsx` | 250+ | Pagamento Pix |

---

## Checklist de Replicação

- [ ] Projeto Manus criado
- [ ] Schema do banco copiado
- [ ] Migração aplicada
- [ ] db.ts implementado
- [ ] routers.ts implementado
- [ ] index.css copiado
- [ ] App.tsx atualizado
- [ ] Home.tsx criado
- [ ] Simulation.tsx criado
- [ ] Proposal.tsx criado
- [ ] Payment.tsx criado
- [ ] axios + qrcode instalados
- [ ] CPFCNPJ_API_TOKEN configurado
- [ ] Testes passando
- [ ] Deploy realizado

---

## Dicas Importantes

✅ **Sempre copiar o arquivo inteiro**, não apenas trechos  
✅ **Testar cada página antes de passar para a próxima**  
✅ **Usar sessionStorage para passar dados entre páginas**  
✅ **Validar CPF com dígito verificador**  
✅ **Fallback para dados mock se API CPF falhar**  
✅ **Nunca mostrar dados pessoais na tela de Pix**  
✅ **Usar "Banco CREDMAIS" como beneficiário**  
✅ **Chave Pix sempre: 420.974.248-3**  

---

## Contato de Suporte

- **Documentação completa:** RELATORIO_CREDMAIS_COMPLETO.md
- **Versão:** 729cb95f
- **Checkpoint:** manus-webdev://729cb95f
