# CREDMAIS - TODO

## Banco de Dados
- [x] Schema: tabela `credit_users` (CPF, nome, data nascimento, score, negativado)
- [x] Schema: tabela `simulations` (CPF, valor, parcelas, taxa, status)
- [x] Schema: tabela `proposals` (simulação, valor aceito, status)
- [x] Schema: tabela `payments` (proposta, valor, pix_id, status, data)
- [x] Migração SQL aplicada

## Backend (tRPC)
- [x] Procedure: `credit.lookup` — busca usuário por CPF + data nascimento
- [x] Procedure: `credit.simulate` — gera propostas de crédito
- [x] Procedure: `credit.acceptProposal` — aceita proposta e gera pagamento Pix
- [x] Procedure: `credit.getPayment` — retorna dados do pagamento
- [x] Geração de QR Code Pix dinâmico (EMV payload)
- [x] Notificação ao proprietário ao aceitar proposta
- [x] Notificação ao proprietário ao pagamento confirmado

## Frontend
- [x] Design global: cores rosa/magenta Serasa, fonte Inter, responsivo
- [x] Header com logo CREDMAIS e menu
- [x] Página Home com hero section e CTA
- [x] Formulário CPF com máscara e validação de dígitos
- [x] Campo data de nascimento
- [x] Tela de carregamento (buscando dados)
- [x] Página de simulação com múltiplas propostas
- [x] Seletor de valor (R$ 1.000 a R$ 15.000)
- [x] Tela de aceite de proposta com detalhes do contrato
- [x] Tela de pagamento Pix com QR Code e chave CPF
- [x] Footer com informações da plataforma
- [x] Design responsivo mobile/desktop

## Qualidade
- [x] Testes vitest para procedures principais (11 testes passando)
- [x] Checkpoint salvo

## Integracao API CPF Real (cpfcnpj.com.br)
- [x] Configurar secret CPFCNPJ_API_TOKEN no projeto
- [x] Integrar chamada real a API cpfcnpj.com.br no backend (procedure credit.lookup)
- [x] Exibir nome real, data de nascimento, endereco e situacao cadastral da Receita Federal
- [x] Exibir saldo devedor simulado baseado nos dados reais do bureau
- [x] Fallback para dados mock quando API nao disponivel
- [x] Atualizar frontend para mostrar dados reais com animacao de buscando
- [x] Teste de validacao da API CPF (cpf-api.test.ts)
