import { Toaster } from "@/components/ui/sonner";
import { TooltipProvider } from "@/components/ui/tooltip";
import NotFound from "@/pages/NotFound";
import { Route, Switch } from "wouter";
import ErrorBoundary from "./components/ErrorBoundary";
import { ThemeProvider } from "./contexts/ThemeContext";
import Home from "./pages/Home";
import Simulation from "./pages/Simulation";
import Proposal from "./pages/Proposal";
import Payment from "./pages/Payment";

function Router() {
  return (
    <Switch>
      <Route path="/" component={Home} />
      <Route path="/simulacao" component={Simulation} />
      <Route path="/proposta/:proposalId" component={Proposal} />
      <Route path="/pagamento/:proposalId" component={Payment} />
      <Route path="/404" component={NotFound} />
      <Route component={NotFound} />
    </Switch>
  );
}

function App() {
  return (
    <ErrorBoundary>
      <ThemeProvider defaultTheme="light">
        <TooltipProvider>
          <Toaster />
          <Router />
        </TooltipProvider>
      </ThemeProvider>
    </ErrorBoundary>
  );
}

export default App;
