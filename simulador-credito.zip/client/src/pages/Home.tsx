import { useState } from "react";
import { useLocation } from "wouter";
import { trpc } from "@/lib/trpc";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { toast } from "sonner";
import {
  Shield, CheckCircle, TrendingUp, Users, Star, ChevronRight,
  Menu, X, Phone, Mail, MapPin, Clock, Award, Zap
} from "lucide-react";

function formatCPF(value: string): string {
  const digits = value.replace(/\D/g, "").substring(0, 11);
  if (digits.length <= 3) return digits;
  if (digits.length <= 6) return `${digits.slice(0, 3)}.${digits.slice(3)}`;
  if (digits.length <= 9) return `${digits.slice(0, 3)}.${digits.slice(3, 6)}.${digits.slice(6)}`;
  return `${digits.slice(0, 3)}.${digits.slice(3, 6)}.${digits.slice(6, 9)}-${digits.slice(9)}`;
}

function formatDate(value: string): string {
  const digits = value.replace(/\D/g, "").substring(0, 8);
  if (digits.length <= 2) return digits;
  if (digits.length <= 4) return `${digits.slice(0, 2)}/${digits.slice(2)}`;
  return `${digits.slice(0, 2)}/${digits.slice(2, 4)}/${digits.slice(4)}`;
}

export default function Home() {
  const [, navigate] = useLocation();
  const [cpf, setCpf] = useState("");
  const [birthDate, setBirthDate] = useState("");
  const [menuOpen, setMenuOpen] = useState(false);
  const [selectedAmount, setSelectedAmount] = useState(5000);

  const lookup = trpc.credit.lookup.useMutation({
    onSuccess: (data) => {
      sessionStorage.setItem("credmais_user", JSON.stringify(data));
      sessionStorage.setItem("credmais_amount", String(selectedAmount));
      navigate("/simulacao");
    },
    onError: (err) => {
      toast.error(err.message || "Erro ao consultar CPF. Verifique os dados e tente novamente.");
    },
  });

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    const rawCpf = cpf.replace(/\D/g, "");
    if (rawCpf.length !== 11) {
      toast.error("CPF deve ter 11 dígitos.");
      return;
    }
    const dateParts = birthDate.split("/");
    if (dateParts.length !== 3 || dateParts[2].length !== 4) {
      toast.error("Data de nascimento inválida. Use o formato DD/MM/AAAA.");
      return;
    }
    const isoDate = `${dateParts[2]}-${dateParts[1]}-${dateParts[0]}`;
    lookup.mutate({ cpf, birthDate: isoDate });
  };

  const creditAmounts = [1000, 1500, 2000, 3000, 5000, 7500, 10000, 15000];

  return (
    <div className="min-h-screen bg-background">
      {/* Header */}
      <header className="bg-white shadow-sm sticky top-0 z-50">
        <div className="container">
          <div className="flex items-center justify-between h-16">
            {/* Logo */}
            <div className="flex items-center gap-2">
              <div className="w-8 h-8 rounded-lg credmais-gradient flex items-center justify-center">
                <span className="text-white font-black text-sm">C+</span>
              </div>
              <span className="font-black text-xl tracking-tight" style={{ color: "oklch(0.52 0.22 350)" }}>
                CREDMAIS
              </span>
            </div>

            {/* Nav Desktop */}
            <nav className="hidden md:flex items-center gap-6 text-sm font-medium text-gray-600">
              <a href="#como-funciona" className="hover:text-primary transition-colors">Como funciona</a>
              <a href="#beneficios" className="hover:text-primary transition-colors">Benefícios</a>
              <a href="#simulador" className="hover:text-primary transition-colors">Simular agora</a>
              <a href="#contato" className="hover:text-primary transition-colors">Contato</a>
            </nav>

            {/* CTA Desktop */}
            <div className="hidden md:flex items-center gap-3">
              <Button
                className="credmais-gradient text-white font-semibold px-5 hover:opacity-90"
                onClick={() => document.getElementById("simulador")?.scrollIntoView({ behavior: "smooth" })}
              >
                Consultar CPF grátis
              </Button>
            </div>

            {/* Mobile menu toggle */}
            <button className="md:hidden p-2" onClick={() => setMenuOpen(!menuOpen)}>
              {menuOpen ? <X className="w-5 h-5" /> : <Menu className="w-5 h-5" />}
            </button>
          </div>

          {/* Mobile menu */}
          {menuOpen && (
            <div className="md:hidden border-t py-4 flex flex-col gap-3 text-sm font-medium">
              <a href="#como-funciona" className="hover:text-primary" onClick={() => setMenuOpen(false)}>Como funciona</a>
              <a href="#beneficios" className="hover:text-primary" onClick={() => setMenuOpen(false)}>Benefícios</a>
              <a href="#simulador" className="hover:text-primary" onClick={() => setMenuOpen(false)}>Simular agora</a>
              <a href="#contato" className="hover:text-primary" onClick={() => setMenuOpen(false)}>Contato</a>
              <Button className="credmais-gradient text-white w-full mt-2">Consultar CPF grátis</Button>
            </div>
          )}
        </div>
      </header>

      {/* Hero Section */}
      <section className="credmais-hero-bg text-white py-16 md:py-24 relative overflow-hidden">
        {/* Decorative circles */}
        <div className="absolute top-0 right-0 w-96 h-96 rounded-full opacity-10" style={{ background: "white", transform: "translate(30%, -30%)" }} />
        <div className="absolute bottom-0 left-0 w-64 h-64 rounded-full opacity-10" style={{ background: "white", transform: "translate(-30%, 30%)" }} />

        <div className="container relative z-10">
          <div className="grid md:grid-cols-2 gap-12 items-center">
            {/* Left: Text */}
            <div>
              <div className="inline-flex items-center gap-2 bg-white/20 rounded-full px-4 py-1.5 text-sm font-medium mb-6">
                <Zap className="w-4 h-4" />
                Aprovação em minutos
              </div>
              <h1 className="text-4xl md:text-5xl font-black leading-tight mb-4">
                Crédito pessoal<br />
                <span className="text-yellow-300">mesmo negativado</span>
              </h1>
              <p className="text-lg text-white/90 mb-8 leading-relaxed">
                Quite suas dívidas, conquiste seu crédito e reconstrua sua vida financeira.
                Consulta gratuita com CPF e data de nascimento.
              </p>
              <div className="flex flex-wrap gap-4 mb-8">
                {[
                  { icon: CheckCircle, text: "Sem consulta ao SPC/Serasa" },
                  { icon: Shield, text: "100% seguro e sigiloso" },
                  { icon: TrendingUp, text: "Até R$ 15.000 aprovados" },
                ].map(({ icon: Icon, text }) => (
                  <div key={text} className="flex items-center gap-2 text-sm">
                    <Icon className="w-4 h-4 text-yellow-300" />
                    <span>{text}</span>
                  </div>
                ))}
              </div>
              <Button
                size="lg"
                className="bg-white text-primary font-bold text-base px-8 py-6 hover:bg-yellow-50 shadow-lg"
                onClick={() => document.getElementById("simulador")?.scrollIntoView({ behavior: "smooth" })}
              >
                Consultar CPF grátis
                <ChevronRight className="w-5 h-5 ml-1" />
              </Button>
            </div>

            {/* Right: Stats */}
            <div className="hidden md:grid grid-cols-2 gap-4">
              {[
                { value: "R$ 15.000", label: "Crédito máximo", icon: TrendingUp },
                { value: "98%", label: "Taxa de aprovação", icon: CheckCircle },
                { value: "5 min", label: "Tempo de análise", icon: Clock },
                { value: "50k+", label: "Clientes atendidos", icon: Users },
              ].map(({ value, label, icon: Icon }) => (
                <div key={label} className="bg-white/15 backdrop-blur rounded-2xl p-5 text-center">
                  <Icon className="w-6 h-6 mx-auto mb-2 text-yellow-300" />
                  <div className="text-2xl font-black">{value}</div>
                  <div className="text-sm text-white/80 mt-1">{label}</div>
                </div>
              ))}
            </div>
          </div>
        </div>
      </section>

      {/* Simulador Form */}
      <section id="simulador" className="py-16 bg-white">
        <div className="container max-w-2xl mx-auto">
          <div className="text-center mb-10">
            <h2 className="text-3xl font-black text-gray-900 mb-3">
              Simule seu crédito agora
            </h2>
            <p className="text-gray-500">
              Preencha seus dados abaixo. A consulta é gratuita e não afeta seu score.
            </p>
          </div>

          <div className="bg-white rounded-3xl shadow-2xl border border-gray-100 p-8">
            {/* Amount selector */}
            <div className="mb-8">
              <Label className="text-base font-semibold text-gray-700 mb-3 block">
                Quanto você precisa?
              </Label>
              <div className="grid grid-cols-4 gap-2">
                {creditAmounts.map((amount) => (
                  <button
                    key={amount}
                    type="button"
                    onClick={() => setSelectedAmount(amount)}
                    className={`py-2.5 px-2 rounded-xl text-sm font-semibold border-2 transition-all ${
                      selectedAmount === amount
                        ? "border-primary bg-primary text-white"
                        : "border-gray-200 text-gray-600 hover:border-primary hover:text-primary"
                    }`}
                  >
                    {amount >= 1000 ? `R$${amount / 1000}k` : `R$${amount}`}
                  </button>
                ))}
              </div>
              <div className="mt-3 text-center">
                <span className="text-2xl font-black text-primary">
                  R$ {selectedAmount.toLocaleString("pt-BR")}
                </span>
                <span className="text-gray-400 text-sm ml-2">selecionado</span>
              </div>
            </div>

            <form onSubmit={handleSubmit} className="space-y-5">
              <div>
                <Label htmlFor="cpf" className="text-sm font-semibold text-gray-700 mb-1.5 block">
                  CPF
                </Label>
                <Input
                  id="cpf"
                  type="text"
                  inputMode="numeric"
                  placeholder="000.000.000-00"
                  value={cpf}
                  onChange={(e) => setCpf(formatCPF(e.target.value))}
                  className="h-12 text-base border-gray-200 focus:border-primary rounded-xl"
                  required
                />
              </div>

              <div>
                <Label htmlFor="birthDate" className="text-sm font-semibold text-gray-700 mb-1.5 block">
                  Data de Nascimento
                </Label>
                <Input
                  id="birthDate"
                  type="text"
                  inputMode="numeric"
                  placeholder="DD/MM/AAAA"
                  value={birthDate}
                  onChange={(e) => setBirthDate(formatDate(e.target.value))}
                  className="h-12 text-base border-gray-200 focus:border-primary rounded-xl"
                  required
                />
              </div>

              <Button
                type="submit"
                disabled={lookup.isPending}
                className="w-full h-14 text-base font-bold credmais-gradient text-white rounded-xl hover:opacity-90 transition-opacity"
              >
                {lookup.isPending ? (
                  <div className="flex items-center gap-3">
                    <div className="w-5 h-5 border-2 border-white/30 border-t-white rounded-full animate-spin" />
                    Consultando seus dados...
                  </div>
                ) : (
                  <div className="flex items-center gap-2">
                    Consultar CPF grátis
                    <ChevronRight className="w-5 h-5" />
                  </div>
                )}
              </Button>

              <p className="text-xs text-gray-400 text-center leading-relaxed">
                Ao continuar, você concorda com nossa{" "}
                <a href="#" className="text-primary underline">Política de Privacidade</a>.
                Seus dados são protegidos e não serão compartilhados.
              </p>
            </form>
          </div>
        </div>
      </section>

      {/* Como funciona */}
      <section id="como-funciona" className="py-16 bg-gray-50">
        <div className="container">
          <div className="text-center mb-12">
            <h2 className="text-3xl font-black text-gray-900 mb-3">Como funciona</h2>
            <p className="text-gray-500 max-w-xl mx-auto">
              Processo simples, rápido e 100% digital. Em poucos minutos você tem o crédito na conta.
            </p>
          </div>
          <div className="grid md:grid-cols-4 gap-6">
            {[
              { step: "01", title: "Informe seu CPF", desc: "Digite seu CPF e data de nascimento. Consulta gratuita e segura.", icon: Shield },
              { step: "02", title: "Análise automática", desc: "Nosso sistema analisa seu perfil e gera propostas personalizadas.", icon: TrendingUp },
              { step: "03", title: "Escolha sua proposta", desc: "Selecione o valor e as parcelas que melhor se encaixam no seu bolso.", icon: CheckCircle },
              { step: "04", title: "Receba o crédito", desc: "Pague a taxa de liberação via Pix e receba o crédito na sua conta.", icon: Zap },
            ].map(({ step, title, desc, icon: Icon }) => (
              <div key={step} className="bg-white rounded-2xl p-6 shadow-sm border border-gray-100 text-center">
                <div className="w-12 h-12 credmais-gradient rounded-2xl flex items-center justify-center mx-auto mb-4">
                  <Icon className="w-6 h-6 text-white" />
                </div>
                <div className="text-4xl font-black text-gray-100 mb-2">{step}</div>
                <h3 className="font-bold text-gray-900 mb-2">{title}</h3>
                <p className="text-sm text-gray-500 leading-relaxed">{desc}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Benefícios */}
      <section id="beneficios" className="py-16 bg-white">
        <div className="container">
          <div className="grid md:grid-cols-2 gap-12 items-center">
            <div>
              <h2 className="text-3xl font-black text-gray-900 mb-6">
                Por que escolher a <span className="text-primary">CREDMAIS</span>?
              </h2>
              <div className="space-y-4">
                {[
                  { title: "Crédito para negativados", desc: "Aprovamos mesmo com restrições no CPF. Nossa análise é diferente." },
                  { title: "Processo 100% digital", desc: "Sem filas, sem burocracia. Tudo pelo celular ou computador." },
                  { title: "Taxas transparentes", desc: "Sem letras miúdas. Você vê exatamente quanto vai pagar." },
                  { title: "Suporte especializado", desc: "Equipe pronta para ajudar você em cada etapa do processo." },
                ].map(({ title, desc }) => (
                  <div key={title} className="flex gap-4">
                    <div className="w-6 h-6 rounded-full bg-primary/10 flex items-center justify-center flex-shrink-0 mt-0.5">
                      <CheckCircle className="w-4 h-4 text-primary" />
                    </div>
                    <div>
                      <h4 className="font-semibold text-gray-900">{title}</h4>
                      <p className="text-sm text-gray-500 mt-0.5">{desc}</p>
                    </div>
                  </div>
                ))}
              </div>
            </div>
            <div className="grid grid-cols-2 gap-4">
              {[
                { value: "R$ 15.000", label: "Limite máximo", color: "bg-primary" },
                { value: "98%", label: "Aprovação", color: "bg-green-500" },
                { value: "12-24x", label: "Parcelas", color: "bg-blue-500" },
                { value: "4,99%", label: "Taxa mensal", color: "bg-orange-500" },
              ].map(({ value, label, color }) => (
                <div key={label} className={`rounded-2xl p-6 text-white text-center ${color}`}>
                  <div className="text-2xl font-black">{value}</div>
                  <div className="text-sm opacity-90 mt-1">{label}</div>
                </div>
              ))}
            </div>
          </div>
        </div>
      </section>

      {/* Depoimentos */}
      <section className="py-16 bg-gray-50">
        <div className="container">
          <h2 className="text-3xl font-black text-gray-900 text-center mb-12">
            O que dizem nossos clientes
          </h2>
          <div className="grid md:grid-cols-3 gap-6">
            {[
              { name: "Maria S.", city: "São Paulo, SP", text: "Estava negativada há 3 anos e consegui crédito de R$ 5.000 em menos de 10 minutos. Incrível!", stars: 5 },
              { name: "Carlos O.", city: "Rio de Janeiro, RJ", text: "Processo super simples. Só precisei do CPF e data de nascimento. Recomendo muito!", stars: 5 },
              { name: "Ana F.", city: "Belo Horizonte, MG", text: "Consegui quitar minhas dívidas com o crédito da CREDMAIS. Vida nova!", stars: 5 },
            ].map(({ name, city, text, stars }) => (
              <div key={name} className="bg-white rounded-2xl p-6 shadow-sm border border-gray-100">
                <div className="flex gap-1 mb-3">
                  {Array.from({ length: stars }).map((_, i) => (
                    <Star key={i} className="w-4 h-4 fill-yellow-400 text-yellow-400" />
                  ))}
                </div>
                <p className="text-gray-700 text-sm leading-relaxed mb-4">"{text}"</p>
                <div>
                  <div className="font-semibold text-gray-900">{name}</div>
                  <div className="text-xs text-gray-400">{city}</div>
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* CTA Final */}
      <section className="credmais-gradient py-16 text-white text-center">
        <div className="container max-w-2xl mx-auto">
          <Award className="w-12 h-12 mx-auto mb-4 text-yellow-300" />
          <h2 className="text-3xl font-black mb-4">Pronto para recomeçar?</h2>
          <p className="text-white/90 mb-8 text-lg">
            Consulte seu CPF agora e descubra quanto crédito você pode ter hoje.
          </p>
          <Button
            size="lg"
            className="bg-white text-primary font-bold text-base px-10 py-6 hover:bg-yellow-50"
            onClick={() => document.getElementById("simulador")?.scrollIntoView({ behavior: "smooth" })}
          >
            Simular crédito grátis
            <ChevronRight className="w-5 h-5 ml-1" />
          </Button>
        </div>
      </section>

      {/* Footer */}
      <footer id="contato" className="bg-gray-900 text-gray-400 py-12">
        <div className="container">
          <div className="grid md:grid-cols-4 gap-8 mb-8">
            <div>
              <div className="flex items-center gap-2 mb-4">
                <div className="w-8 h-8 rounded-lg credmais-gradient flex items-center justify-center">
                  <span className="text-white font-black text-sm">C+</span>
                </div>
                <span className="font-black text-white text-lg">CREDMAIS</span>
              </div>
              <p className="text-sm leading-relaxed">
                Plataforma de crédito pessoal para negativados. Reconstrua sua vida financeira com a CREDMAIS.
              </p>
            </div>
            <div>
              <h4 className="text-white font-semibold mb-3">Serviços</h4>
              <ul className="space-y-2 text-sm">
                <li>Crédito pessoal</li>
                <li>Simulação gratuita</li>
                <li>Consulta de CPF</li>
                <li>Refinanciamento</li>
              </ul>
            </div>
            <div>
              <h4 className="text-white font-semibold mb-3">Institucional</h4>
              <ul className="space-y-2 text-sm">
                <li>Sobre nós</li>
                <li>Política de Privacidade</li>
                <li>Termos de Uso</li>
                <li>Ouvidoria</li>
              </ul>
            </div>
            <div>
              <h4 className="text-white font-semibold mb-3">Contato</h4>
              <ul className="space-y-2 text-sm">
                <li className="flex items-center gap-2"><Phone className="w-4 h-4" /> 0800 000 0000</li>
                <li className="flex items-center gap-2"><Mail className="w-4 h-4" /> contato@credmais.com.br</li>
                <li className="flex items-center gap-2"><MapPin className="w-4 h-4" /> São Paulo, SP</li>
                <li className="flex items-center gap-2"><Clock className="w-4 h-4" /> Seg–Sex 8h–20h</li>
              </ul>
            </div>
          </div>
          <div className="border-t border-gray-800 pt-6 text-center text-xs">
            <p>© 2025 CREDMAIS — Todos os direitos reservados. CNPJ: 00.000.000/0001-00</p>
            <p className="mt-1 text-gray-600">
              A CREDMAIS não é uma instituição financeira. Atuamos como correspondente bancário.
            </p>
          </div>
        </div>
      </footer>
    </div>
  );
}
