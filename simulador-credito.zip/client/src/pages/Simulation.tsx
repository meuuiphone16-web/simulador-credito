import { useState, useEffect } from "react";
import { useLocation } from "wouter";
import { trpc } from "@/lib/trpc";
import { Button } from "@/components/ui/button";
import { toast } from "sonner";
import {
  CheckCircle, ChevronRight, ArrowLeft, Shield, TrendingUp,
  User, MapPin, AlertTriangle, Star, Clock, Zap
} from "lucide-react";

function formatCurrency(value: number): string {
  return value.toLocaleString("pt-BR", { style: "currency", currency: "BRL" });
}

export default function Simulation() {
  const [, navigate] = useLocation();
  const [userData, setUserData] = useState<any>(null);
  const [selectedAmount, setSelectedAmount] = useState(5000);
  const [selectedProposalId, setSelectedProposalId] = useState<number | null>(null);
  const [simulationData, setSimulationData] = useState<any>(null);
  const [step, setStep] = useState<"loading" | "profile" | "proposals">("loading");

  const simulate = trpc.credit.simulate.useMutation({
    onSuccess: (data) => {
      setSimulationData(data);
      sessionStorage.setItem("credmais_simulation", JSON.stringify(data));
      setStep("proposals");
    },
    onError: (err) => {
      toast.error(err.message || "Erro ao gerar simulação.");
      navigate("/");
    },
  });

  useEffect(() => {
    const stored = sessionStorage.getItem("credmais_user");
    const storedAmount = sessionStorage.getItem("credmais_amount");
    if (!stored) { navigate("/"); return; }
    const user = JSON.parse(stored);
    setUserData(user);
    if (storedAmount) setSelectedAmount(parseInt(storedAmount));

    // Simula loading de análise
    setTimeout(() => setStep("profile"), 2000);
  }, []);

  const handleSimulate = () => {
    if (!userData) return;
    simulate.mutate({
      cpf: userData.cpf,
      clientName: userData.name,
      requestedAmount: selectedAmount,
    });
  };

  const handleAcceptProposal = () => {
    if (!selectedProposalId) {
      toast.error("Selecione uma proposta para continuar.");
      return;
    }
    navigate(`/proposta/${selectedProposalId}`);
  };

  const creditAmounts = [1000, 1500, 2000, 3000, 5000, 7500, 10000, 15000];

  // Loading screen
  if (step === "loading") {
    return (
      <div className="min-h-screen credmais-hero-bg flex items-center justify-center">
        <div className="text-center text-white">
          <div className="w-20 h-20 border-4 border-white/30 border-t-white rounded-full animate-spin mx-auto mb-6" />
          <h2 className="text-2xl font-bold mb-2">Consultando seus dados...</h2>
          <p className="text-white/80">Aguarde enquanto analisamos seu perfil de crédito</p>
          <div className="mt-8 space-y-2 text-sm text-white/70">
            <div className="flex items-center gap-2 justify-center">
              <CheckCircle className="w-4 h-4 text-green-300" />
              Verificando CPF nos bureaus de crédito
            </div>
            <div className="flex items-center gap-2 justify-center">
              <CheckCircle className="w-4 h-4 text-green-300" />
              Analisando histórico financeiro
            </div>
            <div className="flex items-center gap-2 justify-center">
              <div className="w-4 h-4 border-2 border-white/30 border-t-white rounded-full animate-spin" />
              Calculando capacidade de crédito
            </div>
          </div>
        </div>
      </div>
    );
  }

  // Profile screen
  if (step === "profile" && userData) {
    return (
      <div className="min-h-screen bg-gray-50">
        {/* Header */}
        <header className="bg-white shadow-sm">
          <div className="container flex items-center justify-between h-16">
            <div className="flex items-center gap-2">
              <div className="w-8 h-8 rounded-lg credmais-gradient flex items-center justify-center">
                <span className="text-white font-black text-sm">C+</span>
              </div>
              <span className="font-black text-xl" style={{ color: "oklch(0.52 0.22 350)" }}>CREDMAIS</span>
            </div>
            <button onClick={() => navigate("/")} className="flex items-center gap-1 text-sm text-gray-500 hover:text-primary">
              <ArrowLeft className="w-4 h-4" /> Voltar
            </button>
          </div>
        </header>

        <div className="container max-w-2xl mx-auto py-10">
          {/* Success banner */}
          <div className="bg-green-50 border border-green-200 rounded-2xl p-5 mb-6 flex items-start gap-3">
            <CheckCircle className="w-6 h-6 text-green-500 flex-shrink-0 mt-0.5" />
            <div>
              <h3 className="font-bold text-green-800">CPF localizado com sucesso!</h3>
              <p className="text-sm text-green-700 mt-0.5">Encontramos seu perfil em nossa base de dados. Confira abaixo.</p>
            </div>
          </div>

          {/* User profile card */}
          <div className="bg-white rounded-3xl shadow-sm border border-gray-100 p-6 mb-6">
            <div className="flex items-center gap-4 mb-6">
              <div className="w-16 h-16 credmais-gradient rounded-2xl flex items-center justify-center">
                <User className="w-8 h-8 text-white" />
              </div>
              <div>
                <h2 className="text-xl font-black text-gray-900">{userData.name}</h2>
                <div className="flex items-center gap-2 text-sm text-gray-500 mt-1">
                  <MapPin className="w-4 h-4" />
                  {userData.city && userData.state ? `${userData.city}, ${userData.state}` : "Brasil"}
                </div>
              </div>
            </div>

            <div className="grid grid-cols-2 gap-4 mb-6">
              <div className="bg-gray-50 rounded-xl p-4">
                <div className="text-xs text-gray-500 mb-1">Score de Crédito</div>
                <div className="text-2xl font-black text-gray-900">{userData.score}</div>
                <div className={`text-xs font-medium mt-1 ${userData.score < 300 ? "text-red-500" : userData.score < 500 ? "text-orange-500" : "text-green-500"}`}>
                  {userData.score < 300 ? "Muito baixo" : userData.score < 500 ? "Baixo" : "Regular"}
                </div>
              </div>
              <div className="bg-gray-50 rounded-xl p-4">
                <div className="text-xs text-gray-500 mb-1">Renda estimada</div>
                <div className="text-2xl font-black text-gray-900">{formatCurrency(userData.income)}</div>
                <div className="text-xs text-gray-400 mt-1">mensal</div>
              </div>
            </div>

            {userData.isNegativado && (
              <div className="bg-orange-50 border border-orange-200 rounded-xl p-4 flex items-start gap-3">
                <AlertTriangle className="w-5 h-5 text-orange-500 flex-shrink-0 mt-0.5" />
                <div>
                  <div className="font-semibold text-orange-800 text-sm">Restrições encontradas</div>
                  <div className="text-xs text-orange-700 mt-0.5">
                    Débito estimado: {formatCurrency(userData.debtAmount)} — Mas não se preocupe, temos crédito para você!
                  </div>
                </div>
              </div>
            )}
          </div>

          {/* Amount selector */}
          <div className="bg-white rounded-3xl shadow-sm border border-gray-100 p-6 mb-6">
            <h3 className="font-bold text-gray-900 mb-4">Quanto você precisa?</h3>
            <div className="grid grid-cols-4 gap-2 mb-4">
              {creditAmounts.map((amount) => (
                <button
                  key={amount}
                  type="button"
                  onClick={() => setSelectedAmount(amount)}
                  className={`py-2.5 px-2 rounded-xl text-sm font-semibold border-2 transition-all ${
                    selectedAmount === amount
                      ? "border-primary bg-primary text-white"
                      : "border-gray-200 text-gray-600 hover:border-primary hover:text-primary"
                  }`}
                >
                  {amount >= 1000 ? `R$${amount / 1000}k` : `R$${amount}`}
                </button>
              ))}
            </div>
            <div className="text-center">
              <span className="text-3xl font-black text-primary">{formatCurrency(selectedAmount)}</span>
            </div>
          </div>

          <Button
            onClick={handleSimulate}
            disabled={simulate.isPending}
            className="w-full h-14 text-base font-bold credmais-gradient text-white rounded-xl"
          >
            {simulate.isPending ? (
              <div className="flex items-center gap-3">
                <div className="w-5 h-5 border-2 border-white/30 border-t-white rounded-full animate-spin" />
                Gerando propostas...
              </div>
            ) : (
              <div className="flex items-center gap-2">
                Ver propostas disponíveis
                <ChevronRight className="w-5 h-5" />
              </div>
            )}
          </Button>
        </div>
      </div>
    );
  }

  // Proposals screen
  if (step === "proposals" && simulationData) {
    return (
      <div className="min-h-screen bg-gray-50">
        {/* Header */}
        <header className="bg-white shadow-sm">
          <div className="container flex items-center justify-between h-16">
            <div className="flex items-center gap-2">
              <div className="w-8 h-8 rounded-lg credmais-gradient flex items-center justify-center">
                <span className="text-white font-black text-sm">C+</span>
              </div>
              <span className="font-black text-xl" style={{ color: "oklch(0.52 0.22 350)" }}>CREDMAIS</span>
            </div>
            <button onClick={() => setStep("profile")} className="flex items-center gap-1 text-sm text-gray-500 hover:text-primary">
              <ArrowLeft className="w-4 h-4" /> Voltar
            </button>
          </div>
        </header>

        {/* Progress bar */}
        <div className="credmais-gradient h-1.5" />

        <div className="container max-w-2xl mx-auto py-10">
          {/* Header */}
          <div className="text-center mb-8">
            <div className="inline-flex items-center gap-2 bg-green-100 text-green-700 rounded-full px-4 py-1.5 text-sm font-semibold mb-4">
              <CheckCircle className="w-4 h-4" />
              Crédito pré-aprovado!
            </div>
            <h2 className="text-2xl font-black text-gray-900 mb-2">
              Olá, {userData?.name?.split(" ")[0]}! Suas propostas estão prontas
            </h2>
            <p className="text-gray-500">Selecione a proposta que melhor se encaixa no seu perfil</p>
          </div>

          {/* Proposals */}
          <div className="space-y-4 mb-6">
            {simulationData.proposals.map((proposal: any, index: number) => (
              <div
                key={proposal.id}
                className={`proposal-card bg-white rounded-2xl border-2 p-6 ${
                  selectedProposalId === proposal.id ? "selected" : "border-gray-100"
                }`}
                onClick={() => setSelectedProposalId(proposal.id)}
              >
                <div className="flex items-start justify-between mb-4">
                  <div>
                    {index === 0 && (
                      <div className="inline-flex items-center gap-1 bg-primary/10 text-primary rounded-full px-3 py-0.5 text-xs font-semibold mb-2">
                        <Star className="w-3 h-3" /> Mais popular
                      </div>
                    )}
                    <div className="text-2xl font-black text-gray-900">
                      {formatCurrency(proposal.approvedAmount)}
                    </div>
                    <div className="text-sm text-gray-500">valor aprovado</div>
                  </div>
                  <div className={`w-6 h-6 rounded-full border-2 flex items-center justify-center flex-shrink-0 ${
                    selectedProposalId === proposal.id
                      ? "border-primary bg-primary"
                      : "border-gray-300"
                  }`}>
                    {selectedProposalId === proposal.id && (
                      <div className="w-2.5 h-2.5 rounded-full bg-white" />
                    )}
                  </div>
                </div>

                <div className="grid grid-cols-3 gap-3">
                  <div className="bg-gray-50 rounded-xl p-3 text-center">
                    <div className="text-xs text-gray-500 mb-1">Parcelas</div>
                    <div className="font-black text-gray-900">{proposal.installments}x</div>
                    <div className="text-xs text-gray-500">{formatCurrency(proposal.installmentValue)}</div>
                  </div>
                  <div className="bg-gray-50 rounded-xl p-3 text-center">
                    <div className="text-xs text-gray-500 mb-1">Taxa mensal</div>
                    <div className="font-black text-gray-900">{proposal.interestRate}%</div>
                    <div className="text-xs text-gray-500">ao mês</div>
                  </div>
                  <div className="bg-gray-50 rounded-xl p-3 text-center">
                    <div className="text-xs text-gray-500 mb-1">Total</div>
                    <div className="font-black text-gray-900 text-sm">{formatCurrency(proposal.totalAmount)}</div>
                    <div className="text-xs text-gray-500">a pagar</div>
                  </div>
                </div>

                <div className="mt-3 flex items-center gap-2 text-xs text-gray-400">
                  <Shield className="w-3 h-3" />
                  Contrato: {proposal.contractNumber}
                </div>
              </div>
            ))}
          </div>

          {/* Trust badges */}
          <div className="flex items-center justify-center gap-6 mb-6 text-xs text-gray-400">
            <div className="flex items-center gap-1"><Shield className="w-3.5 h-3.5" /> 100% seguro</div>
            <div className="flex items-center gap-1"><Clock className="w-3.5 h-3.5" /> Crédito rápido</div>
            <div className="flex items-center gap-1"><Zap className="w-3.5 h-3.5" /> Aprovação imediata</div>
          </div>

          <Button
            onClick={handleAcceptProposal}
            disabled={!selectedProposalId}
            className="w-full h-14 text-base font-bold credmais-gradient text-white rounded-xl disabled:opacity-50"
          >
            <div className="flex items-center gap-2">
              Aceitar proposta selecionada
              <ChevronRight className="w-5 h-5" />
            </div>
          </Button>
        </div>
      </div>
    );
  }

  return null;
}
