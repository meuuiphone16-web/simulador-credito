import { useState, useEffect } from "react";
import { useLocation, useParams } from "wouter";
import { trpc } from "@/lib/trpc";
import { Button } from "@/components/ui/button";
import { toast } from "sonner";
import {
  CheckCircle, ChevronRight, ArrowLeft, Shield, FileText,
  Clock, AlertCircle, User, Calendar, DollarSign, Percent
} from "lucide-react";

function formatCurrency(value: number): string {
  return value.toLocaleString("pt-BR", { style: "currency", currency: "BRL" });
}

export default function Proposal() {
  const params = useParams<{ proposalId: string }>();
  const [, navigate] = useLocation();
  const [userData, setUserData] = useState<any>(null);
  const [simulationData, setSimulationData] = useState<any>(null);
  const [proposal, setProposal] = useState<any>(null);
  const [accepted, setAccepted] = useState(false);

  const acceptProposal = trpc.credit.acceptProposal.useMutation({
    onSuccess: (data) => {
      sessionStorage.setItem("credmais_payment", JSON.stringify(data));
      setAccepted(true);
      setTimeout(() => navigate(`/pagamento/${params.proposalId}`), 1500);
    },
    onError: (err) => {
      toast.error(err.message || "Erro ao aceitar proposta. Tente novamente.");
    },
  });

  useEffect(() => {
    const stored = sessionStorage.getItem("credmais_user");
    const simStored = sessionStorage.getItem("credmais_simulation");
    if (!stored) { navigate("/"); return; }
    const user = JSON.parse(stored);
    setUserData(user);

    if (simStored) {
      const sim = JSON.parse(simStored);
      setSimulationData(sim);
      const found = sim.proposals?.find((p: any) => p.id === parseInt(params.proposalId));
      if (found) setProposal(found);
    }
  }, [params.proposalId]);

  // Also store simulation data when coming from Simulation page
  useEffect(() => {
    const simStored = sessionStorage.getItem("credmais_simulation");
    if (!simStored) {
      // Try to get from URL state or redirect
      const stored = sessionStorage.getItem("credmais_user");
      if (!stored) { navigate("/"); return; }
    }
  }, []);

  // Load proposal from session if available
  useEffect(() => {
    if (!proposal) {
      // Try to reconstruct from stored simulation
      const allKeys = Object.keys(sessionStorage);
      for (const key of allKeys) {
        if (key === "credmais_simulation") {
          try {
            const sim = JSON.parse(sessionStorage.getItem(key) || "{}");
            if (sim.proposals) {
              const found = sim.proposals.find((p: any) => p.id === parseInt(params.proposalId));
              if (found) { setProposal(found); break; }
            }
          } catch {}
        }
      }
    }
  }, [params.proposalId, proposal]);

  const handleAccept = () => {
    if (!userData || !proposal) return;
    acceptProposal.mutate({
      proposalId: parseInt(params.proposalId),
      clientName: userData.name,
      cpf: userData.cpf,
    });
  };

  if (!userData) {
    return (
      <div className="min-h-screen credmais-hero-bg flex items-center justify-center">
        <div className="w-10 h-10 border-2 border-white/30 border-t-white rounded-full animate-spin" />
      </div>
    );
  }

  if (accepted) {
    return (
      <div className="min-h-screen credmais-hero-bg flex items-center justify-center">
        <div className="text-center text-white">
          <div className="w-20 h-20 bg-white/20 rounded-full flex items-center justify-center mx-auto mb-6">
            <CheckCircle className="w-10 h-10 text-green-300" />
          </div>
          <h2 className="text-2xl font-bold mb-2">Proposta aceita!</h2>
          <p className="text-white/80">Redirecionando para o pagamento...</p>
        </div>
      </div>
    );
  }

  // Mock proposal if not found in session (fallback)
  const displayProposal = proposal || {
    approvedAmount: 5000,
    installments: 12,
    installmentValue: 462.50,
    interestRate: 4.99,
    totalAmount: 5550,
    contractNumber: "CM2025" + params.proposalId,
  };

  const today = new Date().toLocaleDateString("pt-BR");
  const dueDate = new Date(Date.now() + 30 * 24 * 60 * 60 * 1000).toLocaleDateString("pt-BR");

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Header */}
      <header className="bg-white shadow-sm">
        <div className="container flex items-center justify-between h-16">
          <div className="flex items-center gap-2">
            <div className="w-8 h-8 rounded-lg credmais-gradient flex items-center justify-center">
              <span className="text-white font-black text-sm">C+</span>
            </div>
            <span className="font-black text-xl" style={{ color: "oklch(0.52 0.22 350)" }}>CREDMAIS</span>
          </div>
          <button onClick={() => navigate("/simulacao")} className="flex items-center gap-1 text-sm text-gray-500 hover:text-primary">
            <ArrowLeft className="w-4 h-4" /> Voltar
          </button>
        </div>
      </header>

      {/* Progress */}
      <div className="bg-white border-b">
        <div className="container py-3">
          <div className="flex items-center gap-2 text-sm">
            <span className="text-gray-400">Simulação</span>
            <ChevronRight className="w-4 h-4 text-gray-300" />
            <span className="text-primary font-semibold">Proposta</span>
            <ChevronRight className="w-4 h-4 text-gray-300" />
            <span className="text-gray-400">Pagamento</span>
          </div>
        </div>
      </div>

      <div className="container max-w-2xl mx-auto py-10">
        {/* Header */}
        <div className="text-center mb-8">
          <div className="inline-flex items-center gap-2 bg-green-100 text-green-700 rounded-full px-4 py-1.5 text-sm font-semibold mb-4">
            <CheckCircle className="w-4 h-4" />
            Proposta aprovada para você!
          </div>
          <h2 className="text-2xl font-black text-gray-900 mb-2">
            Revise os detalhes do seu contrato
          </h2>
          <p className="text-gray-500">Leia com atenção antes de aceitar</p>
        </div>

        {/* Contract card */}
        <div className="bg-white rounded-3xl shadow-sm border border-gray-100 overflow-hidden mb-6">
          {/* Contract header */}
          <div className="credmais-gradient p-6 text-white">
            <div className="flex items-center justify-between mb-4">
              <div className="flex items-center gap-2">
                <FileText className="w-5 h-5" />
                <span className="font-semibold">Contrato de Crédito Pessoal</span>
              </div>
              <span className="text-sm opacity-80">#{displayProposal.contractNumber}</span>
            </div>
            <div className="text-4xl font-black mb-1">
              {formatCurrency(displayProposal.approvedAmount)}
            </div>
            <div className="text-white/80 text-sm">valor aprovado para liberação</div>
          </div>

          {/* Contract details */}
          <div className="p-6">
            <div className="grid grid-cols-2 gap-4 mb-6">
              {[
                { icon: User, label: "Titular", value: userData.name },
                { icon: Calendar, label: "Data do contrato", value: today },
                { icon: Clock, label: "Primeiro vencimento", value: dueDate },
                { icon: DollarSign, label: "Valor da parcela", value: formatCurrency(displayProposal.installmentValue) },
                { icon: Calendar, label: "Número de parcelas", value: `${displayProposal.installments}x` },
                { icon: Percent, label: "Taxa de juros", value: `${displayProposal.interestRate}% a.m.` },
              ].map(({ icon: Icon, label, value }) => (
                <div key={label} className="flex items-start gap-3">
                  <div className="w-8 h-8 bg-primary/10 rounded-lg flex items-center justify-center flex-shrink-0">
                    <Icon className="w-4 h-4 text-primary" />
                  </div>
                  <div>
                    <div className="text-xs text-gray-400">{label}</div>
                    <div className="font-semibold text-gray-900 text-sm">{value}</div>
                  </div>
                </div>
              ))}
            </div>

            {/* Total summary */}
            <div className="bg-gray-50 rounded-2xl p-4 mb-6">
              <div className="flex justify-between items-center mb-2">
                <span className="text-sm text-gray-500">Valor liberado</span>
                <span className="font-semibold">{formatCurrency(displayProposal.approvedAmount)}</span>
              </div>
              <div className="flex justify-between items-center mb-2">
                <span className="text-sm text-gray-500">Total de juros</span>
                <span className="font-semibold text-orange-600">
                  {formatCurrency(displayProposal.totalAmount - displayProposal.approvedAmount)}
                </span>
              </div>
              <div className="border-t border-gray-200 pt-2 mt-2 flex justify-between items-center">
                <span className="font-bold text-gray-900">Total a pagar</span>
                <span className="font-black text-lg text-gray-900">{formatCurrency(displayProposal.totalAmount)}</span>
              </div>
            </div>

            {/* Important notice */}
            <div className="bg-amber-50 border border-amber-200 rounded-xl p-4 mb-6 flex items-start gap-3">
              <AlertCircle className="w-5 h-5 text-amber-500 flex-shrink-0 mt-0.5" />
              <div className="text-sm text-amber-800">
                <strong>Importante:</strong> Para liberação do crédito, é necessário o pagamento de uma taxa de liberação via Pix.
                O valor será creditado em sua conta em até 24 horas após a confirmação.
              </div>
            </div>

            {/* Security badges */}
            <div className="flex items-center justify-center gap-4 mb-6 text-xs text-gray-400">
              <div className="flex items-center gap-1"><Shield className="w-3.5 h-3.5 text-green-500" /> Contrato seguro</div>
              <div className="flex items-center gap-1"><CheckCircle className="w-3.5 h-3.5 text-green-500" /> Dados protegidos</div>
            </div>

            <Button
              onClick={handleAccept}
              disabled={acceptProposal.isPending}
              className="w-full h-14 text-base font-bold credmais-gradient text-white rounded-xl"
            >
              {acceptProposal.isPending ? (
                <div className="flex items-center gap-3">
                  <div className="w-5 h-5 border-2 border-white/30 border-t-white rounded-full animate-spin" />
                  Processando...
                </div>
              ) : (
                <div className="flex items-center gap-2">
                  Aceitar e ir para pagamento
                  <ChevronRight className="w-5 h-5" />
                </div>
              )}
            </Button>

            <p className="text-xs text-gray-400 text-center mt-3">
              Ao aceitar, você concorda com os{" "}
              <a href="#" className="text-primary underline">Termos e Condições</a>{" "}
              do contrato de crédito CREDMAIS.
            </p>
          </div>
        </div>
      </div>
    </div>
  );
}
