import { useState, useEffect, useRef } from "react";
import { useLocation, useParams } from "wouter";
import { trpc } from "@/lib/trpc";
import { Button } from "@/components/ui/button";
import { toast } from "sonner";
import {
  CheckCircle, Copy, Clock, Shield, ArrowLeft,
  ChevronRight, Smartphone, AlertCircle, RefreshCw, FileText
} from "lucide-react";
import QRCode from "qrcode";

function formatCurrency(value: number): string {
  return value.toLocaleString("pt-BR", { style: "currency", currency: "BRL" });
}

function maskCPF(cpf: string): string {
  const clean = cpf.replace(/\D/g, "");
  return `${clean.slice(0, 3)}.***.***-${clean.slice(9)}`;
}

export default function Payment() {
  const params = useParams<{ proposalId: string }>();
  const [, navigate] = useLocation();
  const [paymentData, setPaymentData] = useState<any>(null);
  const [userData, setUserData] = useState<any>(null);
  const [qrCodeUrl, setQrCodeUrl] = useState<string>("");
  const [copied, setCopied] = useState(false);
  const [timeLeft, setTimeLeft] = useState(30 * 60); // 30 minutes
  const [paymentConfirmed, setPaymentConfirmed] = useState(false);
  const canvasRef = useRef<HTMLCanvasElement>(null);

  const confirmPayment = trpc.credit.confirmPayment.useMutation({
    onSuccess: () => {
      setPaymentConfirmed(true);
    },
    onError: (err) => {
      toast.error(err.message || "Erro ao confirmar pagamento.");
    },
  });

  useEffect(() => {
    const stored = sessionStorage.getItem("credmais_payment");
    const userStored = sessionStorage.getItem("credmais_user");
    if (!stored || !userStored) { navigate("/"); return; }
    const payment = JSON.parse(stored);
    const user = JSON.parse(userStored);
    setPaymentData(payment);
    setUserData(user);

    // Generate QR Code from Pix payload
    if (payment.pixQrCode) {
      QRCode.toDataURL(payment.pixQrCode, {
        width: 280,
        margin: 2,
        color: { dark: "#1a1a2e", light: "#ffffff" },
        errorCorrectionLevel: "M",
      }).then((url) => setQrCodeUrl(url)).catch(console.error);
    }
  }, []);

  // Countdown timer
  useEffect(() => {
    if (timeLeft <= 0 || paymentConfirmed) return;
    const timer = setInterval(() => setTimeLeft((t) => t - 1), 1000);
    return () => clearInterval(timer);
  }, [timeLeft, paymentConfirmed]);

  const formatTime = (seconds: number): string => {
    const m = Math.floor(seconds / 60).toString().padStart(2, "0");
    const s = (seconds % 60).toString().padStart(2, "0");
    return `${m}:${s}`;
  };

  const handleCopyPix = () => {
    if (!paymentData?.pixQrCode) return;
    navigator.clipboard.writeText(paymentData.pixQrCode).then(() => {
      setCopied(true);
      toast.success("Código Pix copiado!");
      setTimeout(() => setCopied(false), 3000);
    });
  };

  const handleConfirmPayment = () => {
    if (!paymentData || !userData) return;
    confirmPayment.mutate({
      proposalId: parseInt(params.proposalId),
      clientName: userData.name,
      cpf: userData.cpf,
      amount: paymentData.amount,
    });
  };

  if (!paymentData || !userData) {
    return (
      <div className="min-h-screen credmais-hero-bg flex items-center justify-center">
        <div className="w-10 h-10 border-2 border-white/30 border-t-white rounded-full animate-spin" />
      </div>
    );
  }

  if (paymentConfirmed) {
    return (
      <div className="min-h-screen bg-gray-50 flex items-center justify-center p-4">
        <div className="bg-white rounded-3xl shadow-xl p-10 max-w-md w-full text-center">
          <div className="w-24 h-24 bg-green-100 rounded-full flex items-center justify-center mx-auto mb-6">
            <CheckCircle className="w-12 h-12 text-green-500" />
          </div>
          <h2 className="text-2xl font-black text-gray-900 mb-3">Pagamento confirmado!</h2>
          <p className="text-gray-500 mb-6">
            Seu crédito de <strong className="text-primary">{formatCurrency(paymentData.amount)}</strong> será
            liberado em até 24 horas úteis na sua conta.
          </p>
          <div className="bg-gray-50 rounded-2xl p-4 mb-6 text-left">
            <div className="flex justify-between text-sm mb-2">
              <span className="text-gray-500">Contrato</span>
              <span className="font-semibold">{paymentData.contractNumber}</span>
            </div>
            <div className="flex justify-between text-sm mb-2">
              <span className="text-gray-500">Valor aprovado</span>
              <span className="font-semibold text-primary">{formatCurrency(paymentData.amount)}</span>
            </div>
            <div className="flex justify-between text-sm">
              <span className="text-gray-500">ID da transação</span>
              <span className="font-mono text-xs">{paymentData.pixTxId}</span>
            </div>
          </div>
          <Button
            onClick={() => navigate("/")}
            className="w-full credmais-gradient text-white font-bold h-12"
          >
            Voltar ao início
          </Button>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Header */}
      <header className="bg-white shadow-sm">
        <div className="container flex items-center justify-between h-16">
          <div className="flex items-center gap-2">
            <div className="w-8 h-8 rounded-lg credmais-gradient flex items-center justify-center">
              <span className="text-white font-black text-sm">C+</span>
            </div>
            <span className="font-black text-xl" style={{ color: "oklch(0.52 0.22 350)" }}>CREDMAIS</span>
          </div>
          <button onClick={() => navigate(`/proposta/${params.proposalId}`)} className="flex items-center gap-1 text-sm text-gray-500 hover:text-primary">
            <ArrowLeft className="w-4 h-4" /> Voltar
          </button>
        </div>
      </header>

      {/* Progress */}
      <div className="bg-white border-b">
        <div className="container py-3">
          <div className="flex items-center gap-2 text-sm">
            <span className="text-gray-400">Simulação</span>
            <ChevronRight className="w-4 h-4 text-gray-300" />
            <span className="text-gray-400">Proposta</span>
            <ChevronRight className="w-4 h-4 text-gray-300" />
            <span className="text-primary font-semibold">Pagamento</span>
          </div>
        </div>
      </div>

      <div className="container max-w-2xl mx-auto py-10">
        {/* Header */}
        <div className="text-center mb-8">
          <h2 className="text-2xl font-black text-gray-900 mb-2">
            Finalize seu pagamento via Pix
          </h2>
          <p className="text-gray-500">
            Após o pagamento, seu crédito será liberado em até 24 horas úteis
          </p>
        </div>

        {/* Timer */}
        {timeLeft > 0 ? (
          <div className="bg-amber-50 border border-amber-200 rounded-2xl p-4 mb-6 flex items-center justify-between">
            <div className="flex items-center gap-2 text-amber-700">
              <Clock className="w-5 h-5" />
              <span className="font-semibold text-sm">QR Code válido por</span>
            </div>
            <div className="font-black text-2xl text-amber-700">{formatTime(timeLeft)}</div>
          </div>
        ) : (
          <div className="bg-red-50 border border-red-200 rounded-2xl p-4 mb-6 flex items-center justify-between">
            <div className="flex items-center gap-2 text-red-700">
              <AlertCircle className="w-5 h-5" />
              <span className="font-semibold text-sm">QR Code expirado</span>
            </div>
            <Button size="sm" variant="outline" className="border-red-300 text-red-600" onClick={() => navigate("/")}>
              <RefreshCw className="w-4 h-4 mr-1" /> Nova simulação
            </Button>
          </div>
        )}

        {/* Payment card */}
        <div className="bg-white rounded-3xl shadow-sm border border-gray-100 overflow-hidden mb-6">
          {/* Payment header */}
          <div className="credmais-gradient p-6 text-white text-center">
            <div className="text-sm opacity-80 mb-1">Valor a pagar (taxa de liberação)</div>
            <div className="text-4xl font-black">{formatCurrency(paymentData.amount * 0.1)}</div>
            <div className="text-sm opacity-70 mt-1">
              Para liberar {formatCurrency(paymentData.amount)} em crédito
            </div>
          </div>

          <div className="p-6">
            {/* Beneficiary info */}
            <div className="bg-gray-50 rounded-2xl p-4 mb-6">
              <div className="grid grid-cols-2 gap-3 text-sm">
                <div>
                  <div className="text-gray-400 text-xs mb-0.5">Beneficiário</div>
                  <div className="font-bold text-gray-900">Banco CREDMAIS</div>
                </div>
                <div>
                  <div className="text-gray-400 text-xs mb-0.5">Chave Pix (CPF)</div>
                  <div className="font-bold text-gray-900">420.974.248-3</div>
                </div>
                <div>
                  <div className="text-gray-400 text-xs mb-0.5">Contrato</div>
                  <div className="font-semibold text-gray-700">{paymentData.contractNumber}</div>
                </div>
                <div>
                  <div className="text-gray-400 text-xs mb-0.5">ID da transação</div>
                  <div className="font-mono text-xs text-gray-700">{paymentData.pixTxId}</div>
                </div>
              </div>
            </div>

            {/* QR Code */}
            <div className="text-center mb-6">
              <div className="text-sm font-semibold text-gray-700 mb-4 flex items-center justify-center gap-2">
                <Smartphone className="w-4 h-4" />
                Escaneie o QR Code com seu app de banco
              </div>
              {qrCodeUrl ? (
                <div className="inline-block p-4 bg-white border-2 border-gray-100 rounded-2xl shadow-sm">
                  <img src={qrCodeUrl} alt="QR Code Pix" className="w-56 h-56 mx-auto" />
                </div>
              ) : (
                <div className="w-64 h-64 bg-gray-100 rounded-2xl mx-auto flex items-center justify-center">
                  <div className="w-8 h-8 border-2 border-primary/30 border-t-primary rounded-full animate-spin" />
                </div>
              )}
            </div>

            {/* Pix copy-paste */}
            <div className="mb-6">
              <div className="text-sm font-semibold text-gray-700 mb-2">Ou copie o código Pix:</div>
              <div className="flex gap-2">
                <div className="flex-1 bg-gray-50 border border-gray-200 rounded-xl px-4 py-3 text-xs font-mono text-gray-600 truncate">
                  {paymentData.pixQrCode?.substring(0, 60)}...
                </div>
                <Button
                  variant="outline"
                  size="sm"
                  onClick={handleCopyPix}
                  className={`flex-shrink-0 border-primary text-primary hover:bg-primary hover:text-white ${copied ? "bg-green-50 border-green-500 text-green-600" : ""}`}
                >
                  {copied ? <CheckCircle className="w-4 h-4" /> : <Copy className="w-4 h-4" />}
                  {copied ? "Copiado!" : "Copiar"}
                </Button>
              </div>
            </div>

            {/* Instructions */}
            <div className="bg-blue-50 border border-blue-200 rounded-xl p-4 mb-6">
              <h4 className="font-semibold text-blue-800 text-sm mb-2">Como pagar:</h4>
              <ol className="text-sm text-blue-700 space-y-1 list-decimal list-inside">
                <li>Abra o app do seu banco</li>
                <li>Acesse a opção Pix → Pagar</li>
                <li>Escaneie o QR Code ou cole o código</li>
                <li>Confirme o pagamento de {formatCurrency(paymentData.amount * 0.1)}</li>
                <li>Aguarde a confirmação e liberação do crédito</li>
              </ol>
            </div>

            {/* Contract summary */}
            <div className="border border-gray-100 rounded-xl p-4 mb-6">
              <div className="flex items-center gap-2 mb-3">
                <FileText className="w-4 h-4 text-primary" />
                <span className="font-semibold text-sm text-gray-700">Resumo do contrato</span>
              </div>
              <div className="space-y-2 text-sm">
                <div className="flex justify-between">
                  <span className="text-gray-500">Crédito aprovado</span>
                  <span className="font-bold text-primary">{formatCurrency(paymentData.amount)}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-gray-500">Parcelas</span>
                  <span className="font-semibold">{paymentData.installments}x de {formatCurrency(paymentData.installmentValue)}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-gray-500">Taxa de liberação (Pix)</span>
                  <span className="font-semibold text-orange-600">{formatCurrency(paymentData.amount * 0.1)}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-gray-500">Titular</span>
                  <span className="font-semibold">{userData.name}</span>
                </div>
              </div>
            </div>

            {/* Security */}
            <div className="flex items-center justify-center gap-4 mb-6 text-xs text-gray-400">
              <div className="flex items-center gap-1"><Shield className="w-3.5 h-3.5 text-green-500" /> Pagamento seguro</div>
              <div className="flex items-center gap-1"><CheckCircle className="w-3.5 h-3.5 text-green-500" /> Dados criptografados</div>
            </div>

            {/* Confirm button (for testing / manual confirmation) */}
            <Button
              onClick={handleConfirmPayment}
              disabled={confirmPayment.isPending || timeLeft <= 0}
              className="w-full h-14 text-base font-bold credmais-gradient text-white rounded-xl"
            >
              {confirmPayment.isPending ? (
                <div className="flex items-center gap-3">
                  <div className="w-5 h-5 border-2 border-white/30 border-t-white rounded-full animate-spin" />
                  Confirmando pagamento...
                </div>
              ) : (
                <div className="flex items-center gap-2">
                  Já realizei o pagamento
                  <ChevronRight className="w-5 h-5" />
                </div>
              )}
            </Button>

            <p className="text-xs text-gray-400 text-center mt-3">
              Após confirmar, nossa equipe verificará o pagamento e liberará o crédito.
            </p>
          </div>
        </div>
      </div>
    </div>
  );
}
