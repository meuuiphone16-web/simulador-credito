import { COOKIE_NAME } from "@shared/const";
import { getSessionCookieOptions } from "./_core/cookies";
import { systemRouter } from "./_core/systemRouter";
import { publicProcedure, router } from "./_core/trpc";
import { z } from "zod";
import {
  getCreditUserByCpf,
  createCreditUser,
  createSimulation,
  createProposal,
  getProposalById,
  acceptProposal,
  createPayment,
  getPaymentByProposalId,
} from "./db";
import { notifyOwner } from "./_core/notification";
import { nanoid } from "nanoid";

// ---- Helpers ----

function validateCPF(cpf: string): boolean {
  const cleaned = cpf.replace(/\D/g, "");
  if (cleaned.length !== 11) return false;
  if (/^(\d)\1{10}$/.test(cleaned)) return false;
  let sum = 0;
  for (let i = 0; i < 9; i++) sum += parseInt(cleaned[i]) * (10 - i);
  let remainder = (sum * 10) % 11;
  if (remainder === 10 || remainder === 11) remainder = 0;
  if (remainder !== parseInt(cleaned[9])) return false;
  sum = 0;
  for (let i = 0; i < 10; i++) sum += parseInt(cleaned[i]) * (11 - i);
  remainder = (sum * 10) % 11;
  if (remainder === 10 || remainder === 11) remainder = 0;
  return remainder === parseInt(cleaned[10]);
}

function generateContractNumber(): string {
  const year = new Date().getFullYear();
  const rand = Math.floor(Math.random() * 9000000) + 1000000;
  return `CM${year}${rand}`;
}

// Gera payload EMV Pix estático/dinâmico simplificado
function generatePixPayload(params: {
  pixKey: string;
  merchantName: string;
  merchantCity: string;
  amount: number;
  txId: string;
  description: string;
}): string {
  const { pixKey, merchantName, merchantCity, amount, txId, description } = params;

  function formatField(id: string, value: string): string {
    const len = value.length.toString().padStart(2, "0");
    return `${id}${len}${value}`;
  }

  const pixKeyField = formatField("01", pixKey);
  const descField = formatField("02", description.substring(0, 72));
  const merchantAccountInfo = formatField("26", formatField("00", "BR.GOV.BCB.PIX") + pixKeyField + descField);

  const amountStr = amount.toFixed(2);
  const txIdField = txId.replace(/\W/g, "").substring(0, 25).padEnd(25, "0");

  let payload =
    formatField("00", "01") +
    merchantAccountInfo +
    formatField("52", "0000") +
    formatField("53", "986") +
    formatField("54", amountStr) +
    formatField("58", "BR") +
    formatField("59", merchantName.substring(0, 25)) +
    formatField("60", merchantCity.substring(0, 15)) +
    formatField("62", formatField("05", txIdField));

  // CRC16-CCITT
  payload += "6304";
  let crc = 0xffff;
  for (let i = 0; i < payload.length; i++) {
    crc ^= payload.charCodeAt(i) << 8;
    for (let j = 0; j < 8; j++) {
      if (crc & 0x8000) crc = (crc << 1) ^ 0x1021;
      else crc <<= 1;
      crc &= 0xffff;
    }
  }
  return payload + crc.toString(16).toUpperCase().padStart(4, "0");
}

// Gera propostas de crédito baseadas no perfil do cliente
function generateProposals(baseAmount: number, clientName: string) {
  const proposals = [
    { amount: baseAmount, installments: 12, rate: 4.99 },
    { amount: Math.min(baseAmount * 1.5, 15000), installments: 18, rate: 5.49 },
    { amount: Math.min(baseAmount * 2, 15000), installments: 24, rate: 5.99 },
  ];

  return proposals.map((p) => {
    const monthlyRate = p.rate / 100;
    const installmentValue =
      (p.amount * monthlyRate * Math.pow(1 + monthlyRate, p.installments)) /
      (Math.pow(1 + monthlyRate, p.installments) - 1);
    const totalAmount = installmentValue * p.installments;
    return {
      approvedAmount: parseFloat(p.amount.toFixed(2)),
      installments: p.installments,
      installmentValue: parseFloat(installmentValue.toFixed(2)),
      interestRate: p.rate,
      totalAmount: parseFloat(totalAmount.toFixed(2)),
      contractNumber: generateContractNumber(),
    };
  });
}

// Simula busca de score em bureau externo (mock realista)
function mockBureauLookup(cpf: string, birthDate: string) {
  const cpfNum = parseInt(cpf.replace(/\D/g, "").substring(0, 5));
  const score = 200 + (cpfNum % 400); // Score entre 200-600 (negativado)
  const names = [
    "Ana Silva Santos", "Carlos Oliveira Lima", "Maria Fernanda Costa",
    "João Pedro Souza", "Fernanda Alves Pereira", "Roberto Mendes Carvalho",
    "Luciana Rocha Ferreira", "Marcos Paulo Nascimento", "Patrícia Lima Barbosa",
    "Anderson Gomes Ribeiro", "Juliana Martins Correia", "Felipe Araújo Moreira",
  ];
  const cities = ["São Paulo", "Rio de Janeiro", "Belo Horizonte", "Salvador", "Fortaleza", "Curitiba", "Manaus", "Recife"];
  const states = ["SP", "RJ", "MG", "BA", "CE", "PR", "AM", "PE"];
  const idx = cpfNum % names.length;
  const cityIdx = cpfNum % cities.length;
  return {
    name: names[idx],
    score,
    isNegativado: score < 500,
    debtAmount: score < 400 ? 3500 + (cpfNum % 5000) : 800 + (cpfNum % 2000),
    income: 1200 + (cpfNum % 3000),
    city: cities[cityIdx],
    state: states[cityIdx],
    phone: `(${11 + (cpfNum % 88)}) 9${Math.floor(Math.random() * 9000) + 1000}-${Math.floor(Math.random() * 9000) + 1000}`,
  };
}

// ---- Routers ----

export const appRouter = router({
  system: systemRouter,
  auth: router({
    me: publicProcedure.query((opts) => opts.ctx.user),
    logout: publicProcedure.mutation(({ ctx }) => {
      const cookieOptions = getSessionCookieOptions(ctx.req);
      ctx.res.clearCookie(COOKIE_NAME, { ...cookieOptions, maxAge: -1 });
      return { success: true } as const;
    }),
  }),

  credit: router({
    // Busca usuário por CPF + data de nascimento
    lookup: publicProcedure
      .input(z.object({ cpf: z.string(), birthDate: z.string() }))
      .mutation(async ({ input }) => {
        const { cpf, birthDate } = input;

        if (!validateCPF(cpf)) {
          throw new Error("CPF inválido. Verifique os dígitos informados.");
        }

        // Verifica se já existe no banco
        let creditUser = await getCreditUserByCpf(cpf);

        if (!creditUser) {
          // Simula consulta a bureau externo
          const bureau = mockBureauLookup(cpf, birthDate);
          creditUser = await createCreditUser({
            cpf,
            name: bureau.name,
            birthDate,
            phone: bureau.phone,
            city: bureau.city,
            state: bureau.state,
            score: bureau.score,
            isNegativado: bureau.isNegativado,
            debtAmount: bureau.debtAmount.toFixed(2) as any,
            income: bureau.income.toFixed(2) as any,
          });
        }

        if (!creditUser) throw new Error("Não foi possível localizar os dados. Tente novamente.");

        return {
          id: creditUser.id,
          name: creditUser.name,
          cpf: creditUser.cpf,
          score: creditUser.score ?? 0,
          isNegativado: creditUser.isNegativado ?? true,
          city: creditUser.city,
          state: creditUser.state,
          income: parseFloat(String(creditUser.income ?? "1500")),
          debtAmount: parseFloat(String(creditUser.debtAmount ?? "0")),
        };
      }),

    // Gera simulação de crédito com múltiplas propostas
    simulate: publicProcedure
      .input(z.object({ cpf: z.string(), clientName: z.string(), requestedAmount: z.number().min(1000).max(15000) }))
      .mutation(async ({ input }) => {
        const { cpf, clientName, requestedAmount } = input;

        const simulation = await createSimulation({
          cpf,
          clientName,
          requestedAmount: requestedAmount.toFixed(2) as any,
          status: "approved",
        });

        if (!simulation) throw new Error("Erro ao criar simulação.");

        const proposalData = generateProposals(requestedAmount, clientName);

        const createdProposals = await Promise.all(
          proposalData.map((p) =>
            createProposal({
              simulationId: simulation.id,
              cpf,
              clientName,
              approvedAmount: p.approvedAmount.toFixed(2) as any,
              installments: p.installments,
              installmentValue: p.installmentValue.toFixed(2) as any,
              interestRate: p.interestRate.toFixed(2) as any,
              totalAmount: p.totalAmount.toFixed(2) as any,
              contractNumber: p.contractNumber,
              status: "pending",
            })
          )
        );

        return {
          simulationId: simulation.id,
          proposals: createdProposals.map((p) => ({
            id: p!.id,
            contractNumber: p!.contractNumber,
            approvedAmount: parseFloat(String(p!.approvedAmount)),
            installments: p!.installments,
            installmentValue: parseFloat(String(p!.installmentValue)),
            interestRate: parseFloat(String(p!.interestRate)),
            totalAmount: parseFloat(String(p!.totalAmount)),
            status: p!.status,
          })),
        };
      }),

    // Aceita proposta e gera pagamento Pix
    acceptProposal: publicProcedure
      .input(z.object({ proposalId: z.number(), clientName: z.string(), cpf: z.string() }))
      .mutation(async ({ input }) => {
        const { proposalId, clientName, cpf } = input;

        const proposal = await getProposalById(proposalId);
        if (!proposal) throw new Error("Proposta não encontrada.");
        if (proposal.status !== "pending") throw new Error("Esta proposta não está mais disponível.");

        await acceptProposal(proposalId);

        const amount = parseFloat(String(proposal.approvedAmount));
        const txId = nanoid(20).replace(/[^a-zA-Z0-9]/g, "").substring(0, 20);

        const pixPayload = generatePixPayload({
          pixKey: "42097424883",
          merchantName: "BANCO CREDMAIS",
          merchantCity: "SAO PAULO",
          amount,
          txId,
          description: `CREDMAIS ${proposal.contractNumber}`,
        });

        const payment = await createPayment({
          proposalId,
          cpf,
          clientName,
          amount: amount.toFixed(2) as any,
          pixKey: "420.974.248-3",
          pixTxId: txId,
          pixQrCode: pixPayload,
          status: "pending",
        });

        // Notifica proprietário
        await notifyOwner({
          title: "🎉 Nova Proposta Aceita — CREDMAIS",
          content: `Cliente ${clientName} (CPF: ${cpf}) aceitou proposta de R$ ${amount.toFixed(2)} — Contrato: ${proposal.contractNumber} — TxID Pix: ${txId}`,
        });

        return {
          paymentId: payment!.id,
          proposalId,
          contractNumber: proposal.contractNumber,
          amount,
          pixKey: "420.974.248-3",
          pixTxId: txId,
          pixQrCode: pixPayload,
          beneficiary: "Banco CREDMAIS",
          installments: proposal.installments,
          installmentValue: parseFloat(String(proposal.installmentValue)),
        };
      }),

    // Retorna dados do pagamento
    getPayment: publicProcedure
      .input(z.object({ proposalId: z.number() }))
      .query(async ({ input }) => {
        const payment = await getPaymentByProposalId(input.proposalId);
        if (!payment) return null;
        return {
          id: payment.id,
          amount: parseFloat(String(payment.amount)),
          pixKey: payment.pixKey,
          pixTxId: payment.pixTxId,
          pixQrCode: payment.pixQrCode,
          status: payment.status,
          beneficiary: "Banco CREDMAIS",
        };
      }),

    // Confirma pagamento (webhook simulado)
    confirmPayment: publicProcedure
      .input(z.object({ proposalId: z.number(), clientName: z.string(), cpf: z.string(), amount: z.number() }))
      .mutation(async ({ input }) => {
        const db = await import("./db").then((m) => m.getDb());
        if (!db) throw new Error("Database not available");
        const { payments: paymentsTable } = await import("../drizzle/schema");
        const { eq } = await import("drizzle-orm");
        await db.update(paymentsTable)
          .set({ status: "confirmed", confirmedAt: new Date() })
          .where(eq(paymentsTable.proposalId, input.proposalId));

        await notifyOwner({
          title: "💰 Pagamento Pix Confirmado — CREDMAIS",
          content: `Pagamento de R$ ${input.amount.toFixed(2)} confirmado para ${input.clientName} (CPF: ${input.cpf})`,
        });

        return { success: true };
      }),
  }),
});

export type AppRouter = typeof appRouter;
