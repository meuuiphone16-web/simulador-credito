import { describe, expect, it } from "vitest";
import { appRouter } from "./routers";
import type { TrpcContext } from "./_core/context";

function createPublicContext(): TrpcContext {
  return {
    user: null,
    req: { protocol: "https", headers: {} } as TrpcContext["req"],
    res: { clearCookie: () => {} } as TrpcContext["res"],
  };
}

// Helper to validate CPF (same logic as in routers.ts)
function validateCPF(cpf: string): boolean {
  const cleaned = cpf.replace(/\D/g, "");
  if (cleaned.length !== 11) return false;
  if (/^(\d)\1{10}$/.test(cleaned)) return false;
  let sum = 0;
  for (let i = 0; i < 9; i++) sum += parseInt(cleaned[i]) * (10 - i);
  let remainder = (sum * 10) % 11;
  if (remainder === 10 || remainder === 11) remainder = 0;
  if (remainder !== parseInt(cleaned[9])) return false;
  sum = 0;
  for (let i = 0; i < 10; i++) sum += parseInt(cleaned[i]) * (11 - i);
  remainder = (sum * 10) % 11;
  if (remainder === 10 || remainder === 11) remainder = 0;
  return remainder === parseInt(cleaned[10]);
}

// Helper to generate Pix payload
function generatePixPayload(params: {
  pixKey: string;
  merchantName: string;
  merchantCity: string;
  amount: number;
  txId: string;
  description: string;
}): string {
  const { pixKey, merchantName, merchantCity, amount, txId, description } = params;
  function formatField(id: string, value: string): string {
    const len = value.length.toString().padStart(2, "0");
    return `${id}${len}${value}`;
  }
  const pixKeyField = formatField("01", pixKey);
  const descField = formatField("02", description.substring(0, 72));
  const merchantAccountInfo = formatField("26", formatField("00", "BR.GOV.BCB.PIX") + pixKeyField + descField);
  const amountStr = amount.toFixed(2);
  const txIdField = txId.replace(/\W/g, "").substring(0, 25).padEnd(25, "0");
  let payload =
    formatField("00", "01") +
    merchantAccountInfo +
    formatField("52", "0000") +
    formatField("53", "986") +
    formatField("54", amountStr) +
    formatField("58", "BR") +
    formatField("59", merchantName.substring(0, 25)) +
    formatField("60", merchantCity.substring(0, 15)) +
    formatField("62", formatField("05", txIdField));
  payload += "6304";
  let crc = 0xffff;
  for (let i = 0; i < payload.length; i++) {
    crc ^= payload.charCodeAt(i) << 8;
    for (let j = 0; j < 8; j++) {
      if (crc & 0x8000) crc = (crc << 1) ^ 0x1021;
      else crc <<= 1;
      crc &= 0xffff;
    }
  }
  return payload + crc.toString(16).toUpperCase().padStart(4, "0");
}

describe("CPF Validation", () => {
  it("validates a known valid CPF", () => {
    expect(validateCPF("529.982.247-25")).toBe(true);
  });

  it("rejects a CPF with all same digits", () => {
    expect(validateCPF("111.111.111-11")).toBe(false);
  });

  it("rejects a CPF with wrong check digits", () => {
    expect(validateCPF("529.982.247-00")).toBe(false);
  });

  it("rejects a CPF with wrong length", () => {
    expect(validateCPF("123.456")).toBe(false);
  });

  it("handles CPF without formatting", () => {
    expect(validateCPF("52998224725")).toBe(true);
  });
});

describe("Pix Payload Generation", () => {
  it("generates a non-empty payload", () => {
    const payload = generatePixPayload({
      pixKey: "42097424883",
      merchantName: "BANCO CREDMAIS",
      merchantCity: "SAO PAULO",
      amount: 500.00,
      txId: "CREDMAISTEST12345678",
      description: "CREDMAIS CM2025001",
    });
    expect(payload).toBeTruthy();
    expect(payload.length).toBeGreaterThan(50);
  });

  it("payload starts with 000201 (EMV format)", () => {
    const payload = generatePixPayload({
      pixKey: "42097424883",
      merchantName: "BANCO CREDMAIS",
      merchantCity: "SAO PAULO",
      amount: 1000.00,
      txId: "CREDMAISTEST12345678",
      description: "CREDMAIS CM2025002",
    });
    expect(payload.startsWith("000201")).toBe(true);
  });

  it("payload ends with 4-character CRC", () => {
    const payload = generatePixPayload({
      pixKey: "42097424883",
      merchantName: "BANCO CREDMAIS",
      merchantCity: "SAO PAULO",
      amount: 250.50,
      txId: "CREDMAISTEST12345678",
      description: "CREDMAIS CM2025003",
    });
    // Last 8 chars should be "6304XXXX"
    expect(payload.slice(-8, -4)).toBe("6304");
  });

  it("includes merchant name in payload", () => {
    const payload = generatePixPayload({
      pixKey: "42097424883",
      merchantName: "BANCO CREDMAIS",
      merchantCity: "SAO PAULO",
      amount: 100.00,
      txId: "CREDMAISTEST12345678",
      description: "CREDMAIS CM2025004",
    });
    expect(payload).toContain("BANCO CREDMAIS");
  });
});

describe("auth.logout", () => {
  it("clears session cookie and returns success", async () => {
    const clearedCookies: Array<{ name: string; options: Record<string, unknown> }> = [];
    const ctx: TrpcContext = {
      user: {
        id: 1,
        openId: "test-user",
        email: "test@credmais.com",
        name: "Test User",
        loginMethod: "manus",
        role: "user",
        createdAt: new Date(),
        updatedAt: new Date(),
        lastSignedIn: new Date(),
      },
      req: { protocol: "https", headers: {} } as TrpcContext["req"],
      res: {
        clearCookie: (name: string, options: Record<string, unknown>) => {
          clearedCookies.push({ name, options });
        },
      } as TrpcContext["res"],
    };
    const caller = appRouter.createCaller(ctx);
    const result = await caller.auth.logout();
    expect(result).toEqual({ success: true });
    expect(clearedCookies).toHaveLength(1);
  });
});
