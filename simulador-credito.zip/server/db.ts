import { eq } from "drizzle-orm";
import { drizzle } from "drizzle-orm/mysql2";
import { InsertUser, users, creditUsers, simulations, proposals, payments, InsertCreditUser, InsertSimulation, InsertProposal, InsertPayment } from "../drizzle/schema";
import { ENV } from './_core/env';

let _db: ReturnType<typeof drizzle> | null = null;

export async function getDb() {
  if (!_db && process.env.DATABASE_URL) {
    try {
      _db = drizzle(process.env.DATABASE_URL);
    } catch (error) {
      console.warn("[Database] Failed to connect:", error);
      _db = null;
    }
  }
  return _db;
}

export async function upsertUser(user: InsertUser): Promise<void> {
  if (!user.openId) throw new Error("User openId is required for upsert");
  const db = await getDb();
  if (!db) { console.warn("[Database] Cannot upsert user: database not available"); return; }
  try {
    const values: InsertUser = { openId: user.openId };
    const updateSet: Record<string, unknown> = {};
    const textFields = ["name", "email", "loginMethod"] as const;
    type TextField = (typeof textFields)[number];
    const assignNullable = (field: TextField) => {
      const value = user[field];
      if (value === undefined) return;
      const normalized = value ?? null;
      values[field] = normalized;
      updateSet[field] = normalized;
    };
    textFields.forEach(assignNullable);
    if (user.lastSignedIn !== undefined) { values.lastSignedIn = user.lastSignedIn; updateSet.lastSignedIn = user.lastSignedIn; }
    if (user.role !== undefined) { values.role = user.role; updateSet.role = user.role; }
    else if (user.openId === ENV.ownerOpenId) { values.role = 'admin'; updateSet.role = 'admin'; }
    if (!values.lastSignedIn) values.lastSignedIn = new Date();
    if (Object.keys(updateSet).length === 0) updateSet.lastSignedIn = new Date();
    await db.insert(users).values(values).onDuplicateKeyUpdate({ set: updateSet });
  } catch (error) { console.error("[Database] Failed to upsert user:", error); throw error; }
}

export async function getUserByOpenId(openId: string) {
  const db = await getDb();
  if (!db) { console.warn("[Database] Cannot get user: database not available"); return undefined; }
  const result = await db.select().from(users).where(eq(users.openId, openId)).limit(1);
  return result.length > 0 ? result[0] : undefined;
}

// ---- Credit Users ----
export async function getCreditUserByCpf(cpf: string) {
  const db = await getDb();
  if (!db) return undefined;
  const result = await db.select().from(creditUsers).where(eq(creditUsers.cpf, cpf)).limit(1);
  return result.length > 0 ? result[0] : undefined;
}

export async function createCreditUser(data: InsertCreditUser) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  await db.insert(creditUsers).values(data);
  return getCreditUserByCpf(data.cpf);
}

// ---- Simulations ----
export async function createSimulation(data: InsertSimulation) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  const result = await db.insert(simulations).values(data);
  const insertId = (result as any)[0]?.insertId;
  if (!insertId) throw new Error("Failed to create simulation");
  const rows = await db.select().from(simulations).where(eq(simulations.id, insertId)).limit(1);
  return rows[0];
}

// ---- Proposals ----
export async function createProposal(data: InsertProposal) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  const result = await db.insert(proposals).values(data);
  const insertId = (result as any)[0]?.insertId;
  if (!insertId) throw new Error("Failed to create proposal");
  const rows = await db.select().from(proposals).where(eq(proposals.id, insertId)).limit(1);
  return rows[0];
}

export async function getProposalById(id: number) {
  const db = await getDb();
  if (!db) return undefined;
  const result = await db.select().from(proposals).where(eq(proposals.id, id)).limit(1);
  return result.length > 0 ? result[0] : undefined;
}

export async function acceptProposal(id: number) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  await db.update(proposals).set({ status: "accepted", acceptedAt: new Date() }).where(eq(proposals.id, id));
  return getProposalById(id);
}

// ---- Payments ----
export async function createPayment(data: InsertPayment) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  const result = await db.insert(payments).values(data);
  const insertId = (result as any)[0]?.insertId;
  if (!insertId) throw new Error("Failed to create payment");
  const rows = await db.select().from(payments).where(eq(payments.id, insertId)).limit(1);
  return rows[0];
}

export async function getPaymentByProposalId(proposalId: number) {
  const db = await getDb();
  if (!db) return undefined;
  const result = await db.select().from(payments).where(eq(payments.proposalId, proposalId)).limit(1);
  return result.length > 0 ? result[0] : undefined;
}
