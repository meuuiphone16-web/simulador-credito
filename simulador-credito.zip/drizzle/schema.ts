import { int, mysqlEnum, mysqlTable, text, timestamp, varchar, decimal, boolean } from "drizzle-orm/mysql-core";

export const users = mysqlTable("users", {
  id: int("id").autoincrement().primaryKey(),
  openId: varchar("openId", { length: 64 }).notNull().unique(),
  name: text("name"),
  email: varchar("email", { length: 320 }),
  loginMethod: varchar("loginMethod", { length: 64 }),
  role: mysqlEnum("role", ["user", "admin"]).default("user").notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
  lastSignedIn: timestamp("lastSignedIn").defaultNow().notNull(),
});

export type User = typeof users.$inferSelect;
export type InsertUser = typeof users.$inferInsert;

// Tabela de clientes de crédito (dados consultados por CPF)
export const creditUsers = mysqlTable("credit_users", {
  id: int("id").autoincrement().primaryKey(),
  cpf: varchar("cpf", { length: 14 }).notNull().unique(),
  name: varchar("name", { length: 255 }).notNull(),
  birthDate: varchar("birthDate", { length: 10 }).notNull(),
  email: varchar("email", { length: 320 }),
  phone: varchar("phone", { length: 20 }),
  city: varchar("city", { length: 100 }),
  state: varchar("state", { length: 2 }),
  score: int("score").default(0),
  isNegativado: boolean("isNegativado").default(true),
  debtAmount: decimal("debtAmount", { precision: 10, scale: 2 }).default("0"),
  income: decimal("income", { precision: 10, scale: 2 }).default("1500"),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
});

export type CreditUser = typeof creditUsers.$inferSelect;
export type InsertCreditUser = typeof creditUsers.$inferInsert;

// Tabela de simulações
export const simulations = mysqlTable("simulations", {
  id: int("id").autoincrement().primaryKey(),
  cpf: varchar("cpf", { length: 14 }).notNull(),
  clientName: varchar("clientName", { length: 255 }).notNull(),
  requestedAmount: decimal("requestedAmount", { precision: 10, scale: 2 }).notNull(),
  status: mysqlEnum("status", ["pending", "approved", "rejected", "accepted"]).default("pending").notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
});

export type Simulation = typeof simulations.$inferSelect;
export type InsertSimulation = typeof simulations.$inferInsert;

// Tabela de propostas de crédito
export const proposals = mysqlTable("proposals", {
  id: int("id").autoincrement().primaryKey(),
  simulationId: int("simulationId").notNull(),
  cpf: varchar("cpf", { length: 14 }).notNull(),
  clientName: varchar("clientName", { length: 255 }).notNull(),
  approvedAmount: decimal("approvedAmount", { precision: 10, scale: 2 }).notNull(),
  installments: int("installments").notNull(),
  installmentValue: decimal("installmentValue", { precision: 10, scale: 2 }).notNull(),
  interestRate: decimal("interestRate", { precision: 5, scale: 2 }).notNull(),
  totalAmount: decimal("totalAmount", { precision: 10, scale: 2 }).notNull(),
  contractNumber: varchar("contractNumber", { length: 20 }).notNull(),
  status: mysqlEnum("status", ["pending", "accepted", "rejected", "paid"]).default("pending").notNull(),
  acceptedAt: timestamp("acceptedAt"),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
});

export type Proposal = typeof proposals.$inferSelect;
export type InsertProposal = typeof proposals.$inferInsert;

// Tabela de pagamentos Pix
export const payments = mysqlTable("payments", {
  id: int("id").autoincrement().primaryKey(),
  proposalId: int("proposalId").notNull(),
  cpf: varchar("cpf", { length: 14 }).notNull(),
  clientName: varchar("clientName", { length: 255 }).notNull(),
  amount: decimal("amount", { precision: 10, scale: 2 }).notNull(),
  pixKey: varchar("pixKey", { length: 50 }).notNull().default("420.974.248-3"),
  pixTxId: varchar("pixTxId", { length: 50 }).notNull(),
  pixQrCode: text("pixQrCode"),
  status: mysqlEnum("status", ["pending", "confirmed", "expired"]).default("pending").notNull(),
  confirmedAt: timestamp("confirmedAt"),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
});

export type Payment = typeof payments.$inferSelect;
export type InsertPayment = typeof payments.$inferInsert;
