CREATE TABLE `credit_users` (
	`id` int AUTO_INCREMENT NOT NULL,
	`cpf` varchar(14) NOT NULL,
	`name` varchar(255) NOT NULL,
	`birthDate` varchar(10) NOT NULL,
	`email` varchar(320),
	`phone` varchar(20),
	`city` varchar(100),
	`state` varchar(2),
	`score` int DEFAULT 0,
	`isNegativado` boolean DEFAULT true,
	`debtAmount` decimal(10,2) DEFAULT '0',
	`income` decimal(10,2) DEFAULT '1500',
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	`updatedAt` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
	CONSTRAINT `credit_users_id` PRIMARY KEY(`id`),
	CONSTRAINT `credit_users_cpf_unique` UNIQUE(`cpf`)
);
--> statement-breakpoint
CREATE TABLE `payments` (
	`id` int AUTO_INCREMENT NOT NULL,
	`proposalId` int NOT NULL,
	`cpf` varchar(14) NOT NULL,
	`clientName` varchar(255) NOT NULL,
	`amount` decimal(10,2) NOT NULL,
	`pixKey` varchar(50) NOT NULL DEFAULT '420.974.248-3',
	`pixTxId` varchar(50) NOT NULL,
	`pixQrCode` text,
	`status` enum('pending','confirmed','expired') NOT NULL DEFAULT 'pending',
	`confirmedAt` timestamp,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	`updatedAt` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
	CONSTRAINT `payments_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `proposals` (
	`id` int AUTO_INCREMENT NOT NULL,
	`simulationId` int NOT NULL,
	`cpf` varchar(14) NOT NULL,
	`clientName` varchar(255) NOT NULL,
	`approvedAmount` decimal(10,2) NOT NULL,
	`installments` int NOT NULL,
	`installmentValue` decimal(10,2) NOT NULL,
	`interestRate` decimal(5,2) NOT NULL,
	`totalAmount` decimal(10,2) NOT NULL,
	`contractNumber` varchar(20) NOT NULL,
	`status` enum('pending','accepted','rejected','paid') NOT NULL DEFAULT 'pending',
	`acceptedAt` timestamp,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	`updatedAt` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
	CONSTRAINT `proposals_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `simulations` (
	`id` int AUTO_INCREMENT NOT NULL,
	`cpf` varchar(14) NOT NULL,
	`clientName` varchar(255) NOT NULL,
	`requestedAmount` decimal(10,2) NOT NULL,
	`status` enum('pending','approved','rejected','accepted') NOT NULL DEFAULT 'pending',
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	`updatedAt` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
	CONSTRAINT `simulations_id` PRIMARY KEY(`id`)
);
